</div>
<!-- Content ends -->

<?php get_sidebar();?>
</div>
<!-- Wrapper ends -->

<!-- begin footer -->

<div id="footer">
  <table cellpadding="0" cellspacing="0" class="footertable">
    <tr>
      <td align="left" valign="middle">&nbsp;Copyright &copy; <?php echo date('Y'); ?> <a href="<?php bloginfo('url') ?>">
        <?php bloginfo('name'); ?>
        </a> all rights reserved.</td>
      <td align="right" valign="middle"> Proudly powered by WordPress. <br />
        Theme designed by <a href="http://linesh.com"><span class="red">Linesh Jose</span></a>.</td>
    </tr>
  </table>
</div>
<?php wp_footer(); ?>
<!-- end footer -->

</div>
<!-- end Container -->

</body></html><!-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++Site ends+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->